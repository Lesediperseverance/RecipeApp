﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;


namespace RecipePart3_GUI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private List<Recipe> recipes = new List<Recipe>();
        public ObservableCollection<Ingredient> Ingredients { get; set; }

        public MainWindow()
        {
            InitializeComponent();
            Ingredients = new ObservableCollection<Ingredient>();
            ingredientsDataGrid.ItemsSource = Ingredients;
        }

        private void AddRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            string recipeName = recipeNameTextBox.Text;
            if (string.IsNullOrWhiteSpace(recipeName))
            {
                MessageBox.Show("Please enter a recipe name.");
                return;
            }

            Recipe newRecipe = new Recipe
            {
                Name = recipeName,
                Ingredients = ingredientsDataGrid.Items.OfType<Ingredient>().ToList(),
                Steps = new List<Step> { new Step { Description = stepsTextBox.Text } }
            };

            recipes.Add(newRecipe);
            recipeListBox.ItemsSource = recipes.OrderBy(r => r.Name);
            ClearRecipeForm();
        }

        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            string searchText = searchTextBox.Text.Trim();

            // Clear the selection in the recipeListBox
            recipeListBox.SelectedItem = null;

            // Check if the search query is empty
            if (string.IsNullOrEmpty(searchText))
            {
                // If the search query is empty, display all recipes
                recipeListBox.ItemsSource = recipes;
            }
            else
            {
                // If the search query is not empty, perform the search
                List<Recipe> searchResults = new List<Recipe>();

                // Perform the search logic by iterating through the recipes and checking for a match
                foreach (Recipe recipe in recipes)
                {
                    if (recipe.Name.Contains(searchText))
                    {
                        // If the recipe name contains the search query, add it to the search results
                        searchResults.Add(recipe);
                    }
                }

                // Update the recipeListBox to display the search results
                recipeListBox.ItemsSource = searchResults;
            }
        }

        private void ResetQuantitiesButton_Click(object sender, RoutedEventArgs e)
        {
            ClearRecipeForm();
        }

        private void ClearDataButton_Click(object sender, RoutedEventArgs e)
        {
            recipes.Clear();
            //recipeListBox.ItemsSource = null;

            ClearRecipeForm();
        }

        private void RecipeListBox_SelectionChanged(object sender, RoutedEventArgs e)
        {
            Recipe selectedRecipe = recipeListBox.SelectedItem as Recipe;
            if (selectedRecipe != null)
            {
                fullRecipeTextBox.Text = GenerateFullRecipeText(selectedRecipe);
            }
        }

        private string GenerateFullRecipeText(Recipe recipe)
        {
            string fullRecipe = $"Recipe: {recipe.Name}\n\nIngredients:\n";
            foreach (Ingredient ingredient in recipe.Ingredients)
            {
                fullRecipe += $"{ingredient.Name} - {ingredient.Quantity} {ingredient.Unit}\n";
            }

            fullRecipe += $"\nSteps:\n{recipe.Steps.FirstOrDefault()?.Description}";

            return fullRecipe;
        }

        private void ClearRecipeForm()
        {
            recipeNameTextBox.Text = string.Empty;
            Ingredients.Clear();
            stepsTextBox.Text = string.Empty;
            fullRecipeTextBox.Text = string.Empty;
        }

        private void AddingNewItemEventArgs(object sender, System.Windows.Controls.AddingNewItemEventArgs e)
        {
            e.NewItem = new Ingredient();
        }

        private void FilterRecipesButton_Click(object sender, RoutedEventArgs e)
        {
            string ingredientName = searchTextBox.Text.ToLower();

            List<Recipe> filteredRecipes = new List<Recipe>();

            foreach (Recipe recipe in recipeListBox.Items)
            {
                bool hasIngredient = recipe.Ingredients.Any(ingredient => ingredient.Name.ToLower().Contains(ingredientName));
                if (hasIngredient)
                {
                    filteredRecipes.Add(recipe);
                }
            }

            recipeListBox.ItemsSource = filteredRecipes;
        }

        private void FilterMaxCalRecipesButton_Click(object sender, RoutedEventArgs e)
        {
            if (int.TryParse(searchTextBox.Text, out int maxCalories))
            {
                List<Recipe> filteredRecipes = new List<Recipe>();

                foreach (Recipe recipe in recipeListBox.Items)
                {
                    int totalCalories = recipe.Ingredients.Sum(ingredient => ingredient.Calories);
                    if (totalCalories == maxCalories)
                    {
                        filteredRecipes.Add(recipe);
                    }
                }

                recipeListBox.ItemsSource = filteredRecipes;
            }
            else
            {
                MessageBox.Show("Please enter a valid maximum calories value.", "Invalid Input", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

    }

    public class Recipe
    {
        public string Name { get; set; }
        public List<Ingredient> Ingredients { get; set; }
        public List<Step> Steps { get; set; }

        public Recipe()
        {
            Ingredients = new List<Ingredient>();
            Steps = new List<Step>();
        }
    }

    public class Ingredient
    {
        public string Name { get; set; }
        public double Quantity { get; set; }
        public string Unit { get; set; }
        public int Calories { get; set; }
        public string FoodGroup { get; set; }
    }

    public class Step
    {
        public string Description { get; set; }
    }
}
